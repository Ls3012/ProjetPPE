<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="contactersinama.css" >
    <title>Sinama</title>
  </head>
  <body>

    <div class="body2">
    <!-- je veux un bouton pour qu'il puisse s'inscrire au dessus de la barre ! -->
<a class="btConnexion" href="pageConnexion.html" >&nbsp;CONNEXION&nbsp;</a>
<img src="logociné2.png" alt="" width="200" />

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>

    <!-- la navbar de l'accueil du site -->
    <?php
       include 'scriptphp\bandeau.php';
     ?>

<!-- image qui défile sur les évènements et autres PROMOTIONS et OFFRES-->
< src="Salle-cinema-vide-776x390.jpg" alt="Nouveau !" />
<CENTER>
<div style="width: 800px;  display:block; position:static; padding-top:10px; padding-bottom:10px;border: 2px solid black; text-align: center; background: #353A3F; border-radius: 5px;">
</br>
<p>
 <b><font color="red" size=+3 >Nous contacter</font></p></b>
 </p>
 Besoin de conseils ou d'informations, nous sommes là pour vous aider.
</br>
</br>
<b><font color="red" size=+3 >Service client</font></p></b>
Vous souhaitez obtenir des informations
</br>
Vous pouvez nous joindre :
</br>
</br>
<li>Par téléphone :</li>
Nous sommes disponibles du lundi au vendredi de 8h à 19h et le samedi de 8h à 12h.
</br>
09 69 391 391 (appel non surtaxe)
</br>
</br>
<li>Par email:</li>
sinama@hotmail.fr
</br>
</br>
</div>
</CENTER>

</body>
</html>
